import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminRoutingModule } from './admin-routing.module';
import { FormsModule } from '@angular/forms';
import { InventoryComponent } from './inventory/inventory.component';
import { HttpClientModule } from '@angular/common/http';
import { SearchFilterPipe } from './inventory/pipe/search-filter.pipe';



@NgModule({
  declarations: [
  
  
    InventoryComponent,
          SearchFilterPipe
  ],
  imports: [
    CommonModule,AdminRoutingModule,FormsModule,HttpClientModule,
  ],
  
})
export class AdminModule { }
