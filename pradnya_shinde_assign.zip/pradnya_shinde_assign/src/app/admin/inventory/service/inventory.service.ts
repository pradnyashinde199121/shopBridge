import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class InventoryService {

  constructor(private http:HttpClient) { }

  getInvventory(){
    const url="./assets/invData.json";
    return this.http.get(url);
  }
  deleteInvventory(data:any){
    const url=environment.baseUrl+"";
    return this.http.post(url,data);
  }
  updateInventory(data:any){
    const url=environment.baseUrl+"";
    return this.http.post(url,data);
  }
  addInvventory(data:any){
    const url=environment.baseUrl+"";
    return this.http.post(url,data);
  }
}

