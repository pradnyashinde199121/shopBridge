import { Component, OnInit } from '@angular/core';
import {InventoryService} from './service/inventory.service';
import {SearchFilterPipe} from './pipe/search-filter.pipe'

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {
  invvData: any;
  deleteResp:any
  searchText:any;
  newData:any={};

  constructor(private InventoryService:InventoryService) { }

  ngOnInit(): void {
    this.getInventoryData();
  }

  getInventoryData(){
    this.InventoryService.getInvventory().subscribe(x=>{
      this.invvData=x;
    } ,(error:any)=>{
      // alert(error.error.message);    
      // alert("no API");  
      }
    );

  }

  deleteData(data:any){
    this.InventoryService.deleteInvventory(data).subscribe(x=>{
      this.deleteResp=x;
    }
    ,(error:any)=>{
      // alert(error.error.message);    
      alert("no API");  
      }
    );
  }
  editdetail(detail: any){
    detail.editable = !detail.editable;  
    const updateData={id:detail.id,name:detail.name,description:detail.Desciption,price:detail.price};
    this.InventoryService.updateInventory(updateData).subscribe(x=>{
      this.deleteResp=x;
    },(error:any)=>{
      // alert(error.error.message);  
      // alert("no API");  
      }
    );
  }

  addItem(detail:any) {
    this.invvData.push(this.newData);
    this.newData={};
    // const addData={id:detail.id,name:detail.name,description:detail.Desciption,price:detail.price};
    // this.InventoryService.addInvventory(addData).subscribe((x:any)=>{
    //   console.log("------addeded record-----");
    //   console.log(x);
    // },(error:any)=>{
    //   // alert(error.error.message);    
    //   }
    // );
    
 
  }
}
